package com.example.newuser.blogchennel;

public class Intent_Constants {
    public final static int INTENT_REQUEST_CODE=1;
    public final static int INTENT_RESULT_CODE=1;
    public final static int INTENT_REQUEST_CODE_2=2;
    public final static int INTENT_RESULT_CODE_2=2;
    public final static String INTENT_MESSAGE_FIELD="message_fields";
    public final static String INTENT_MESSAGE_DATA="message_data";
    public final static String INTENT_ITEM_POSITION="item_position";
    public final static String INTENT_CHANGE_MESSAGE="change_message";
    public final static String INTENT_CHANGE_DATE="change_date";

}

