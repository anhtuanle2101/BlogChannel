package com.example.newuser.blogchennel;

import java.io.Serializable;

public class Blog implements Serializable {
    public Blog() {
        this.title = null;
        this.content = null;
        this.date = null;
    }
    public Blog(String title, String content, String date){
        this.title = title;
        this.content = content;
        this.date =date;
    }
    public void setTitle (String title) {
        this.title = title;
    }
    public  void setContent (String content){
        this.content = content;
    }
    public void setDate (String date){
        this.date = date;
    }
    public String getInfo(int id_code){
        if (id_code == 0){
            return title;
        }
        else if (id_code == 1){
            return content;
        }
        else{
            return date;
        }
    }
    private String title;
    private String content;
    private String date;
}
