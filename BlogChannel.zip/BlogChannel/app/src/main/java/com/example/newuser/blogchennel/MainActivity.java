package com.example.newuser.blogchennel;

import android.content.Intent;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.util.Log;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.ListView;

import java.util.ArrayList;

public class MainActivity extends AppCompatActivity {
    ListView listView;
    ArrayList<String> arrayList;
    ArrayAdapter<String> arrayAdapter;
    ArrayList<Blog> arrayBlog;
    String messageText;
    int position;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        listView= (ListView) findViewById(R.id.listView);
        arrayBlog = new ArrayList<>();
        arrayList=new ArrayList<>();

        if (arrayBlog.size() > 0) {
            for (int i = 0 ; i < arrayBlog.size(); ++i){
                arrayList.add(arrayBlog.get(i).getInfo(0));
            }
        }

        arrayAdapter=new ArrayAdapter<>(this,android.R.layout.simple_list_item_1,arrayList);
        listView.setAdapter(arrayAdapter);

        listView.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
                Intent intent=new Intent(MainActivity.this,ContentClass.class);
                intent.putExtra(Intent_Constants.INTENT_MESSAGE_DATA,arrayBlog.get(position).getInfo(1));
                intent.putExtra(Intent_Constants.INTENT_CHANGE_DATE,arrayBlog.get(position).getInfo(2));

                startActivityForResult(intent,Intent_Constants.INTENT_REQUEST_CODE_2);
                Log.d("tap", arrayBlog.get(position).getInfo(1));
            }
        });
    }
    public void onClickAdd(View v){
        Intent intent=new Intent();
        intent.setClass(MainActivity.this,EditFieldClass.class);
        startActivityForResult(intent,Intent_Constants.INTENT_REQUEST_CODE);
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        if(resultCode==Intent_Constants.INTENT_REQUEST_CODE) {
        //data = getIntent();
       Blog aBlog = (Blog)data.getSerializableExtra(Intent_Constants.INTENT_MESSAGE_FIELD);
        // messageText = data.getStringExtra(Intent_Constants.INTENT_MESSAGE_FIELD);
            messageText = aBlog.getInfo(0);
            arrayBlog.add(aBlog);
            arrayList.add(messageText);

            arrayAdapter.notifyDataSetChanged();
        }
        else{if(resultCode==Intent_Constants.INTENT_RESULT_CODE_2){

        }
        }
    }
}
