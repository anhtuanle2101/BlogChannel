package com.example.newuser.blogchennel;

import android.content.Intent;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.view.View;
import android.widget.EditText;

import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Locale;

public class EditFieldClass extends AppCompatActivity {
    private static final DateFormat sdf = new SimpleDateFormat("MM/dd/yyyy", Locale.US);

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.blog_layout);
    }

    public void saveButtonClicked(View v){
        String messageText=((EditText) findViewById(R.id.message)).getText().toString();
        String messageText2=((EditText) findViewById(R.id.content)).getText().toString();
        if (messageText.equals("")){

        }
        else{
            Blog abLog = new Blog();

            long timemiles = System.currentTimeMillis();

            Date date = new Date();
            date.setTime(timemiles);
            String today = sdf.format(date);
            abLog.setTitle(messageText);
            abLog.setContent(messageText2);
            abLog.setDate(today);
            Intent intent=new Intent(this,MainActivity.class);
            intent.putExtra(Intent_Constants.INTENT_MESSAGE_FIELD,abLog);
            setResult(Intent_Constants.INTENT_RESULT_CODE,intent);
            finish();
        }
    }
}
