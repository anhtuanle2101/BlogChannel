package com.example.newuser.blogchennel;

import android.content.Intent;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.widget.TextView;

public class ContentClass extends AppCompatActivity {
    private String contentText;
    private String date;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.content_layout);
        Intent intent= getIntent();
        contentText=intent.getStringExtra(Intent_Constants.INTENT_MESSAGE_DATA);
        date = intent.getStringExtra(Intent_Constants.INTENT_CHANGE_DATE);
        TextView myTextView=(TextView) findViewById(R.id.textView);
        String concate = date + contentText;
        myTextView.setText(concate);
    }
}
